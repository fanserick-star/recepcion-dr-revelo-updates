from __future__ import annotations

import os
import re
import subprocess
import threading
import time
import urllib.request
from pathlib import Path
from urllib.parse import urlparse

CLOUDFLARED_DOWNLOAD_URL = "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe"
_QUICK_URL_RE = re.compile(r"https://[a-z0-9-]+\.trycloudflare\.com", re.I)

_lock = threading.RLock()
_state = {
    "process": None,
    "mode": "off",
    "public_base_url": "",
    "started_at": None,
    "last_error": "",
    "downloading": False,
    "tool_ready": False,
}


def _hidden_flags() -> int:
    return getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0


def _tool_dir(data_dir: str | os.PathLike[str]) -> Path:
    path = Path(data_dir) / "remote_agenda"
    path.mkdir(parents=True, exist_ok=True)
    return path


def cloudflared_path(data_dir: str | os.PathLike[str]) -> Path:
    base = _tool_dir(data_dir)
    return base / ("cloudflared.exe" if os.name == "nt" else "cloudflared")


def _pid_path(data_dir: str | os.PathLike[str]) -> Path:
    return _tool_dir(data_dir) / "cloudflared.pid"


def normalize_public_base_url(value: str) -> str:
    raw = str(value or "").strip().rstrip("/")
    if not raw:
        return ""
    parsed = urlparse(raw)
    if parsed.scheme.lower() != "https" or not parsed.hostname:
        raise ValueError("El enlace público debe comenzar con https://")
    if parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise ValueError("El enlace público debe ser solo el dominio HTTPS, sin usuario, parámetros ni #.")
    path = (parsed.path or "").rstrip("/")
    if path not in {"", "/"}:
        raise ValueError("El enlace público no debe incluir una ruta adicional.")
    port = f":{parsed.port}" if parsed.port else ""
    return f"https://{parsed.hostname}{port}"


def _cloudflared_version(path: Path) -> str:
    if not path.exists():
        return ""
    try:
        proc = subprocess.run(
            [str(path), "--version"], capture_output=True, text=True, timeout=6,
            check=False, creationflags=_hidden_flags(),
        )
        text = ((proc.stdout or "") + " " + (proc.stderr or "")).strip()
        return text[:180]
    except Exception:
        return ""


def ensure_cloudflared(data_dir: str | os.PathLike[str]) -> dict:
    """Descarga cloudflared solo cuando se solicita acceso remoto.

    No se ejecuta en el arranque normal salvo que exista un túnel estable ya
    configurado. La descarga queda en data/ para sobrevivir actualizaciones.
    """
    path = cloudflared_path(data_dir)
    version = _cloudflared_version(path)
    if version:
        with _lock:
            _state["tool_ready"] = True
        return {"ready": True, "path": str(path), "version": version, "downloaded": False}

    with _lock:
        if _state["downloading"]:
            return {"ready": False, "path": str(path), "version": "", "downloaded": False, "busy": True}
        _state["downloading"] = True
    tmp = path.with_suffix(path.suffix + ".download")
    try:
        req = urllib.request.Request(CLOUDFLARED_DOWNLOAD_URL, headers={"User-Agent": "Recepcion-Dr-Revelo/4.3.32"})
        with urllib.request.urlopen(req, timeout=45) as src, open(tmp, "wb") as dst:
            while True:
                chunk = src.read(1024 * 1024)
                if not chunk:
                    break
                dst.write(chunk)
        if tmp.stat().st_size < 5_000_000:
            raise RuntimeError("La descarga de cloudflared quedó incompleta.")
        os.replace(tmp, path)
        if os.name != "nt":
            try:
                path.chmod(0o755)
            except Exception:
                pass
        version = _cloudflared_version(path)
        if not version:
            raise RuntimeError("cloudflared se descargó, pero Windows no pudo ejecutarlo.")
        with _lock:
            _state["tool_ready"] = True
        return {"ready": True, "path": str(path), "version": version, "downloaded": True}
    finally:
        with _lock:
            _state["downloading"] = False
        try:
            if tmp.exists():
                tmp.unlink()
        except Exception:
            pass


def _pid_is_cloudflared(pid: int) -> bool:
    if pid <= 0:
        return False
    if os.name == "nt":
        try:
            proc = subprocess.run(
                ["tasklist", "/FI", f"PID eq {pid}", "/FO", "CSV", "/NH"],
                capture_output=True, text=True, timeout=5, check=False,
                creationflags=_hidden_flags(),
            )
            return "cloudflared.exe" in (proc.stdout or "").lower()
        except Exception:
            return False
    try:
        target = os.readlink(f"/proc/{pid}/exe")
        return "cloudflared" in Path(target).name.lower()
    except Exception:
        return False


def _kill_pid(pid: int) -> None:
    if not _pid_is_cloudflared(pid):
        return
    try:
        if os.name == "nt":
            subprocess.run(
                ["taskkill", "/PID", str(pid), "/T", "/F"],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=8,
                check=False, creationflags=_hidden_flags(),
            )
        else:
            import signal
            os.kill(pid, signal.SIGTERM)
    except Exception:
        pass


def stop_managed_tunnel(data_dir: str | os.PathLike[str]) -> None:
    with _lock:
        proc = _state.get("process")
        if proc is not None:
            try:
                if proc.poll() is None:
                    proc.terminate()
                    try:
                        proc.wait(timeout=4)
                    except Exception:
                        proc.kill()
            except Exception:
                pass
        _state.update({"process": None, "mode": "off", "public_base_url": "", "started_at": None})
    pidfile = _pid_path(data_dir)
    try:
        if pidfile.exists():
            pid = int(pidfile.read_text(encoding="utf-8").strip() or "0")
            _kill_pid(pid)
            pidfile.unlink(missing_ok=True)
    except Exception:
        pass


def _register_process(proc: subprocess.Popen, data_dir: str | os.PathLike[str], mode: str, base_url: str = "") -> None:
    with _lock:
        _state.update({
            "process": proc,
            "mode": mode,
            "public_base_url": base_url,
            "started_at": time.time(),
            "last_error": "",
        })
    try:
        _pid_path(data_dir).write_text(str(proc.pid), encoding="utf-8")
    except Exception:
        pass


def _isolated_env(data_dir: str | os.PathLike[str]) -> dict:
    env = os.environ.copy()
    home = _tool_dir(data_dir) / "home"
    home.mkdir(parents=True, exist_ok=True)
    # Evita que una configuración ~/.cloudflared ajena al consultorio interfiera
    # con los Quick Tunnels de prueba.
    env["HOME"] = str(home)
    env["USERPROFILE"] = str(home)
    return env


def start_quick_tunnel(data_dir: str | os.PathLike[str], origin: str = "http://127.0.0.1:8000", wait_seconds: float = 18.0) -> dict:
    tool = ensure_cloudflared(data_dir)
    if not tool.get("ready"):
        raise RuntimeError("cloudflared todavía se está preparando.")
    stop_managed_tunnel(data_dir)
    exe = cloudflared_path(data_dir)
    env = _isolated_env(data_dir)
    proc = subprocess.Popen(
        [str(exe), "tunnel", "--url", origin],
        cwd=str(_tool_dir(data_dir)), env=env,
        stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, encoding="utf-8", errors="replace", bufsize=1,
        creationflags=_hidden_flags(),
    )
    _register_process(proc, data_dir, "quick", "")

    found = threading.Event()
    lines: list[str] = []

    def _reader() -> None:
        try:
            assert proc.stdout is not None
            for line in proc.stdout:
                text = line.strip()
                if text:
                    lines.append(text[-500:])
                    if len(lines) > 20:
                        del lines[:-20]
                match = _QUICK_URL_RE.search(text)
                if match:
                    with _lock:
                        _state["public_base_url"] = match.group(0).rstrip("/")
                    found.set()
            if proc.poll() not in (None, 0) and not found.is_set():
                with _lock:
                    _state["last_error"] = (lines[-1] if lines else "Cloudflare Tunnel terminó antes de publicar el enlace.")[:500]
                found.set()
        except Exception as exc:
            with _lock:
                _state["last_error"] = str(exc)[:500]
            found.set()

    threading.Thread(target=_reader, name="remote-agenda-quick-log", daemon=True).start()
    found.wait(max(1.0, float(wait_seconds)))
    status = tunnel_status(data_dir)
    if not status.get("public_base_url"):
        if proc.poll() is None:
            with _lock:
                _state["last_error"] = _state.get("last_error") or "Cloudflare sigue conectando. Pulsa Actualizar en unos segundos."
        else:
            raise RuntimeError(status.get("last_error") or "No se pudo iniciar el túnel de prueba.")
    return tunnel_status(data_dir)


def start_named_tunnel(data_dir: str | os.PathLike[str], tunnel_token: str, public_base_url: str, origin: str = "http://127.0.0.1:8000") -> dict:
    """Inicia un túnel administrado por Cloudflare.

    El hostname/origen se configuran en el dashboard de Cloudflare. El token se
    pasa por TUNNEL_TOKEN (no por la línea de comandos) para no exponerlo en la
    lista de procesos de Windows.
    """
    token = str(tunnel_token or "").strip()
    if not token:
        raise ValueError("Falta el token del túnel estable.")
    base = normalize_public_base_url(public_base_url)
    if not base:
        raise ValueError("Falta el enlace HTTPS estable.")
    tool = ensure_cloudflared(data_dir)
    if not tool.get("ready"):
        raise RuntimeError("cloudflared todavía se está preparando.")
    stop_managed_tunnel(data_dir)
    exe = cloudflared_path(data_dir)
    env = _isolated_env(data_dir)
    env["TUNNEL_TOKEN"] = token
    # El origen se define en el Public Hostname del dashboard. Dejamos una pista
    # no secreta para diagnóstico y mantenemos el token fuera del comando.
    env["REVELO_TUNNEL_ORIGIN"] = origin
    log_path = _tool_dir(data_dir) / "cloudflared.log"
    log = open(log_path, "ab", buffering=0)
    try:
        proc = subprocess.Popen(
            [str(exe), "tunnel", "--no-autoupdate", "run"],
            cwd=str(_tool_dir(data_dir)), env=env,
            stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
            creationflags=_hidden_flags(),
        )
    finally:
        log.close()
    _register_process(proc, data_dir, "stable", base)
    time.sleep(0.7)
    if proc.poll() is not None:
        raise RuntimeError("Cloudflare Tunnel no pudo iniciar. Revisa el token y el hostname configurado.")
    return tunnel_status(data_dir)


def start_named_tunnel_background(data_dir: str | os.PathLike[str], tunnel_token: str, public_base_url: str) -> None:
    token = str(tunnel_token or "").strip()
    base = str(public_base_url or "").strip()
    if not token or not base:
        return

    def _worker() -> None:
        try:
            start_named_tunnel(data_dir, token, base)
        except Exception as exc:
            with _lock:
                _state["last_error"] = str(exc)[:500]

    threading.Thread(target=_worker, name="remote-agenda-stable", daemon=True).start()


def tunnel_status(data_dir: str | os.PathLike[str]) -> dict:
    path = cloudflared_path(data_dir)
    with _lock:
        proc = _state.get("process")
        running = bool(proc is not None and proc.poll() is None)
        if proc is not None and not running and _state.get("mode") != "off":
            _state["last_error"] = _state.get("last_error") or "El túnel se detuvo."
        return {
            "running": running,
            "mode": _state.get("mode") if running else "off",
            "public_base_url": _state.get("public_base_url") if running else "",
            "started_at": _state.get("started_at") if running else None,
            "last_error": _state.get("last_error") or "",
            "cloudflared_ready": bool(path.exists() and (_state.get("tool_ready") or _cloudflared_version(path))),
            "downloading": bool(_state.get("downloading")),
        }
